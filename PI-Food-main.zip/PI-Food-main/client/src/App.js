import './App.css';

function App() {
  return (
    <div className="App">
      <h1>Henry Food</h1>
    </div>
  );
}

export default App;
